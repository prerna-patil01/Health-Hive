import React from 'react';
import { Activity, Calendar, FileText, Users } from 'lucide-react';

const Dashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Health Dashboard</h2>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          icon={<Activity className="h-6 w-6 text-green-600" />}
          title="Health Score"
          value="85%"
          description="Overall wellness index"
        />
        <StatCard
          icon={<Calendar className="h-6 w-6 text-blue-600" />}
          title="Next Appointment"
          value="Mar 15"
          description="Dr. Smith - Checkup"
        />
        <StatCard
          icon={<FileText className="h-6 w-6 text-purple-600" />}
          title="Health Records"
          value="12"
          description="Updated 2 days ago"
        />
        <StatCard
          icon={<Users className="h-6 w-6 text-orange-600" />}
          title="Consultations"
          value="5"
          description="This month"
        />
      </div>

      {/* Additional dashboard content can be added here */}
    </div>
  );
};

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  description: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, description }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="bg-gray-50 p-3 rounded-lg">{icon}</div>
      </div>
      <h3 className="text-sm font-medium text-gray-600">{title}</h3>
      <p className="text-2xl font-semibold text-gray-900 mb-1">{value}</p>
      <p className="text-sm text-gray-500">{description}</p>
    </div>
  );
};

export default Dashboard;