import React from 'react';
import { X } from 'lucide-react';

interface AboutUsProps {
  onClose: () => void;
}

const AboutUs: React.FC<AboutUsProps> = ({ onClose }) => {
  const team = [
    {
      name: "Prerna Patil",
      role: "CEO",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80",
    },
    {
      name: "Deepshika Reddy",
      role: "COO",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=800&q=80",
    },
    {
      name: "Grishma Chowdary",
      role: "CFO & Marketing Officer",
      image: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?auto=format&fit=crop&w=800&q=80",
    },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl p-8 max-w-4xl w-full relative">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-400 hover:text-gray-600"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">About HealthHive</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            HealthHive is revolutionizing healthcare through artificial intelligence. Our platform combines cutting-edge AI technology with medical expertise to provide accessible, efficient, and personalized healthcare solutions.
          </p>
        </div>

        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Our Leadership Team</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member) => (
              <div key={member.name} className="text-center">
                <div className="mb-4">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto object-cover"
                  />
                </div>
                <h4 className="text-xl font-semibold text-gray-900">{member.name}</h4>
                <p className="text-gray-600">{member.role}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We're committed to making healthcare more accessible, efficient, and personalized through the power of artificial intelligence. Our goal is to empower individuals to take control of their health journey while providing healthcare professionals with innovative tools to deliver better care.
          </p>
        </div>
      </div>
    </div>
  );
};

export default AboutUs;